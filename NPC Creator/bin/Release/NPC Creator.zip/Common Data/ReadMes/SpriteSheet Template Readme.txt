﻿*****************************************************************************************************
The most basic NPC Spritesheet Setup is 16 walking frames, four frames for each direction.
Each sprite has a maximum area of 16x32 and are lined in rows of 4.  The spritesheet cannot
expand horizontally, only vertically.  Refer to the Spritesheet map in order to set up
reserved animations and frames for datable NPCs.
*****************************************************************************************************