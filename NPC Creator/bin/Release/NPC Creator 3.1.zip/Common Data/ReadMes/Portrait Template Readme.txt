﻿*****************************************************************************************************************
Portraits are detailed face pictures of your NPC.  The Template Shows what kind of image should be in each
area.  Remember that each Frame is 64x64.  The image can be extended downward but not horizontally.  You can add
more space if you want to, just be sure it is in multiples of 64 or you will get memory overflow errors and your
mod will crash.
*****************************************************************************************************************